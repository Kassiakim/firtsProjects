/**
 * DESAFIO1 Unisinos - Sistemas de Informação 2021/1
 * @author (Kassia Alves) - 10/03/2021
 * Empresa escolhida: Udemy - cursos 
 */
 
public class DESAFIO1
{
    public static void main (String [] args){
        
    System.out.println ("--- BEM VINDOS AO SISTEMA DE CADASTRO DA UDEMY ---");
    System.out.println ("Informe os dados abaixo para realizar seu cadastro:");
    String nome = Teclado.leString ("Nome:");
    String sobrenome = Teclado.leString ("Sobrenome:");
    String email = Teclado.leString ("Digite seu email:");
    int idade = Teclado.leInt ("Digite sua idade:");
    String enderecoRua = Teclado.leString ("Digite seu endereço:"); 
    int enderecoNumero = Teclado.leInt ("Digite o número/apartamento:");
    String cidade = Teclado.leString ("Digite a cidade:");
    String bairro = Teclado.leString ("Digite o bairro:");
    String nivelEscolar = Teclado.leString ("Digite sua escolaridade:");
    String curso = Teclado.leString ("Digite o curso escolhido:"); 
    
    System.out.println ("\r\n");
    System.out.println (" -- Cadastro realizado.Verifique sua caixa de email para orientações. -- ");
    System.out.println ("\r\n");
    System.out.println ("Resumo do seu cadastro:");
    System.out.println ("Nome:" + nome  );
    System.out.println ("Email:" + email);
    System.out.println ("Idade:" + idade );
    System.out.println ("Endereço:" + enderecoRua);
    System.out.println ("Número e/ou apartamento:" + enderecoNumero );
    System.out.println ("Cidade:" + cidade );
    System.out.println ("Bairro:" + bairro );
    System.out.println ("Escolaridade:" + nivelEscolar);
    System.out.println ("Curso escolhido:" + curso);
    
    
    
    
   
}
    
    
    
    
    
    
    
}